package com.attendance.employee.entities;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "attendance_records")
public class AttendanceRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name="type")
    private String type;

    @Column(name="createddate")
    private LocalDateTime createdDate;

    @Column(name = "attendance_date", nullable = false)
    private LocalDate attendanceDate;

    @Column(name="employeeid")
    private Long employeeId;
    

}