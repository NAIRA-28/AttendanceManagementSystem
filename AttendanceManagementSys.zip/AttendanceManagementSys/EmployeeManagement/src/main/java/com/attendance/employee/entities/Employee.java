package com.attendance.employee.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@RequiredArgsConstructor
@Table(name = "employees")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @NotBlank(message = "Employee name is required")
    @Column(name="name")
    private String name;

    @Email(message = "Valid email is required")
    @Column(name="email")
    private String email;

    @CreationTimestamp
    @Column(name = "createddate")
    private LocalDateTime createdDate;
}
