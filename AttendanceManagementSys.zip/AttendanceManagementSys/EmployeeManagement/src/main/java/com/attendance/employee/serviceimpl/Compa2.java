package com.attendance.employee.serviceimpl;

public class Compa2 implements Comparable<Compa2>{
    int id;
    String name;

    Compa2(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public int compareTo(Compa2 o) {
        return this.id - o.id;
    }
    @Override
    public String toString() {
        return id + " - " + name;
    }

}
