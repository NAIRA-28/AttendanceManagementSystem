package com.attendance.employee.config;

public enum Constants {
    PUNCH_IN("Punch In"),
    PUNCH_OUT("Punch Out"),
    SUCCESS("Success"),
    SUCCESSFULLY_FETCHED("Successfully_fetched"),
    ERROR("Error"),
    ERROR_FETCHED("Error In fetching Data");


    private final String displayName;

    Constants(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
