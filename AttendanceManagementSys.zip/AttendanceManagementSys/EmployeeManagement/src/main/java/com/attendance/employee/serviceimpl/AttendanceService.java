package com.attendance.employee.serviceimpl;
import com.attendance.employee.config.Constants;
import com.attendance.employee.dto.*;
import com.attendance.employee.entities.AttendanceRecord;
import com.attendance.employee.entities.Employee;
import com.attendance.employee.exceptions.EmployeeNotFoundException;
import com.attendance.employee.repository.AttendanceRecordRepository;
import com.attendance.employee.repository.EmployeeRepository;

import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AttendanceService{

        private final AttendanceRecordRepository attendanceRepository;
        private final EmployeeRepository employeeRepository;

        public AttendanceResponse markAttendance(AttendanceRequest request) {
            //get the employee details from employee table else throw exception
            Employee employee = employeeRepository.findById(request.getEmployeeId())
                    .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with ID: " + request.getEmployeeId()));

            // Get the last attendance record for validation

            Optional<AttendanceRecord> lastRecord = attendanceRepository
                    .findLastAttendanceByEmployeeId(employee.getId())
                    .stream()
                    .findFirst();

            String nextType = determineNextAttendanceType(lastRecord);
            LocalDateTime now = LocalDateTime.now();

            AttendanceRecord newRecord = AttendanceRecord.builder()
                    .type(nextType)
                    .createdDate(now)
                    .attendanceDate(now.toLocalDate())
                    .employeeId(request.getEmployeeId())
                    .build();

            AttendanceRecord savedRecord = attendanceRepository.save(newRecord);

            String message = generateAttendanceMessage(nextType, employee.getName());
			/*
			 * AttendanceResponse attResp=new AttendanceResponse();
			 * attResp.setId(savedRecord.getId());
			 */
            return AttendanceResponse.builder()
                    .id(savedRecord.getId())
                    .employeeId(employee.getId())
                    .employeeName(employee.getName())
                    .type(nextType)
                    .timestamp(now)
                    .message(message)
                    .build();
        }

        private String determineNextAttendanceType(Optional<AttendanceRecord> lastRecord) {
            if (lastRecord.isEmpty()) {
                return Constants.PUNCH_IN.getDisplayName();
            }

            String lastType = lastRecord.get().getType();
            if (lastType.equalsIgnoreCase(Constants.PUNCH_IN.getDisplayName())) {
                return Constants.PUNCH_OUT.getDisplayName();
            } else {
                return Constants.PUNCH_IN.getDisplayName();
            }
        }

        private String generateAttendanceMessage(String type, String employeeName) {
            if (type.equalsIgnoreCase(Constants.PUNCH_IN.getDisplayName())) {
                return employeeName + " punched in successfully";
            } else {
                return employeeName + " punched out successfully";
            }
        }

        public AttendanceSummaryDTO getAttendanceSummary(Long employeeId, LocalDate fromDate, LocalDate toDate) {
            Employee employee = employeeRepository.findById(employeeId)
                    .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with ID: " + employeeId));

            List<AttendanceRecord> records = attendanceRepository.findByEmployeeIdAndDateBetween(
                    employeeId, fromDate, toDate);

            AttendanceSummaryDTO summary = new AttendanceSummaryDTO();
            summary.setEmployeeId(employeeId);
            summary.setEmployeeName(employee.getName());
            summary.setFromDate(fromDate);
            summary.setToDate(toDate);

            // Group records by date
            Map<LocalDate, List<AttendanceRecord>> dailyRecords = records.stream()
                    .collect(Collectors.groupingBy(AttendanceRecord::getAttendanceDate));

            List<DailyAttendanceDTO> dailyAttendances = new ArrayList<>();
            double totalWorkingHours = 0.0;
            int workingDays = 0;

            for (LocalDate date = fromDate; !date.isAfter(toDate); date = date.plusDays(1)) {
                List<AttendanceRecord> dayRecords = dailyRecords.getOrDefault(date, new ArrayList<>());

                if (!dayRecords.isEmpty()) {
                    DailyAttendanceDTO dailyDTO = processDailyAttendance(date, dayRecords);
                    dailyAttendances.add(dailyDTO);
                    totalWorkingHours += dailyDTO.getTotalHours();
                    if (dailyDTO.getTotalHours() > 0) {
                        workingDays++;
                    }
                }
            }

            summary.setDailyAttendances(dailyAttendances);
            summary.setTotalWorkingHours(Math.round(totalWorkingHours * 100.0) / 100.0);
            summary.setTotalWorkingDays(workingDays);
            summary.setAverageHoursPerDay(workingDays > 0 ?
                    Math.round((totalWorkingHours / workingDays) * 100.0) / 100.0 : 0.0);

            return summary;
        }

        private DailyAttendanceDTO processDailyAttendance(LocalDate date, List<AttendanceRecord> records) {
            records.sort((r1, r2) -> r1.getCreatedDate().compareTo(r2.getCreatedDate()));

            List<AttendanceRecordDTO> recordDTOs = records.stream()
                    .map(r -> AttendanceRecordDTO.builder().id(r.getId()).type(r.getType()).timestamp(r.getCreatedDate()).build())
                    .toList();

            double totalHours = calculateTotalHours(records);
            int sessions = countCompleteSessions(records);

            return DailyAttendanceDTO.builder().date(date).records(recordDTOs).totalHours(totalHours).totalSessions(sessions).build();
        }

        private double calculateTotalHours(List<AttendanceRecord> records) {
            double totalHours = 0.0;
            LocalDateTime punchInTime = null;

            for (AttendanceRecord record : records) {
                if (record.getType().equalsIgnoreCase(Constants.PUNCH_IN.getDisplayName())) {
                    punchInTime = record.getCreatedDate();
                } else if (record.getType().equalsIgnoreCase(Constants.PUNCH_OUT.getDisplayName()) && punchInTime != null) {
                    Duration duration = Duration.between(punchInTime, record.getCreatedDate());
                    totalHours += duration.toMinutes() / 60.0;
                    punchInTime = null;
                }
            }

            return Math.round(totalHours * 100.0) / 100.0;
        }

        private int countCompleteSessions(List<AttendanceRecord> records) {
            int sessions = 0;
            boolean isPunchedIn = false;

            for (AttendanceRecord record : records) {
                if (record.getType().equalsIgnoreCase(Constants.PUNCH_IN.getDisplayName())) {
                    isPunchedIn = true;
                } else if (record.getType().equalsIgnoreCase(Constants.PUNCH_OUT.getDisplayName()) && isPunchedIn) {
                    sessions++;
                    isPunchedIn = false;
                }
            }

            return sessions;
        }

    }

