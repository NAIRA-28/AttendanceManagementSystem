package com.attendance.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.attendance.employee.entities.AttendanceRecord;

import java.awt.print.Pageable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceRecordRepository extends JpaRepository<AttendanceRecord, Long> {

    @Query("SELECT a FROM AttendanceRecord a WHERE a.employeeId = :id ORDER BY a.createdDate DESC")
    List<AttendanceRecord> findLastAttendanceByEmployeeId(@Param("id") Long id);

    @Query("SELECT a FROM AttendanceRecord a WHERE a.employeeId = :employeeId " +
            "AND a.attendanceDate BETWEEN :fromDate AND :toDate " +
            "ORDER BY a.createdDate ASC")
    List<AttendanceRecord> findByEmployeeIdAndDateBetween(
            @Param("employeeId") Long employeeId,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate);
}
