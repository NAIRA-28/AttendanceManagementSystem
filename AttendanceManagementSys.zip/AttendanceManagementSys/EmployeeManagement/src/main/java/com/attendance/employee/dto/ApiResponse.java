package com.attendance.employee.dto;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class ApiResponse {

    private String status;

    private String errorCode;

    private String msg;

    private Object data;

}