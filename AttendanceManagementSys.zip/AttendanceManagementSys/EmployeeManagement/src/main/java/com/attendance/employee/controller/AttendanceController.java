package com.attendance.employee.controller;
import com.attendance.employee.config.Constants;
import com.attendance.employee.dto.ApiResponse;
import com.attendance.employee.dto.AttendanceRequest;
import com.attendance.employee.dto.AttendanceResponse;
import com.attendance.employee.dto.AttendanceSummaryDTO;
import com.attendance.employee.entities.Employee;
import com.attendance.employee.serviceimpl.AttendanceService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/attendance")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class AttendanceController {

    private final AttendanceService attendanceService;

    @PostMapping("/mark")
    //http://localhost:8086/api/attendance/mark
    public ResponseEntity<ApiResponse> markAttendance(@Valid @RequestBody AttendanceRequest request) {
        ApiResponse apiResponse;
        try {
            AttendanceResponse response = attendanceService.markAttendance(request);
            apiResponse = ApiResponse.builder().status(Constants.SUCCESS.getDisplayName())
                      .msg(Constants.SUCCESSFULLY_FETCHED.getDisplayName()).data(response).build();
            return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
        } catch (IllegalArgumentException ex) {
            apiResponse = ApiResponse.builder().status(Constants.ERROR.getDisplayName())
                    .msg(Constants.ERROR_FETCHED.getDisplayName()).errorCode("300").data(ex.getMessage()).build();
            return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
        }
    }

    @GetMapping("/summary")
    //http://localhost:8086/api/attendance/summary?employeeId=1&from=2025-11-01&to=2025-11-05
    public ResponseEntity<ApiResponse> getAttendanceSummary(
            @RequestParam Long employeeId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            //Dates are automatically parsed to LocalDate using @DateTimeFormat
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        ApiResponse apiResponse;
        try {
            AttendanceSummaryDTO summary = attendanceService.getAttendanceSummary(employeeId, from, to);
            apiResponse = ApiResponse.builder().status(Constants.SUCCESS.getDisplayName())
                    .msg(Constants.SUCCESSFULLY_FETCHED.getDisplayName()).data(summary).build();
            return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
        } catch (IllegalArgumentException ex) {
            apiResponse = ApiResponse.builder().status(Constants.ERROR.getDisplayName())
                    .msg(Constants.ERROR_FETCHED.getDisplayName()).errorCode("300").data(ex.getMessage()).build();
            return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
        }
    }
    
	/*http://localhost:8086/api/attendance/summary?employeeId=1&from=2025-11-01&to=2025-11-05

	 * @GetMapping("/get-month-wise") public ResponseEntity<ApiResponse>
	 * getAttendanceSummary(
	 * 
	 * @RequestParam Long employeeId,
	 * 
	 * @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
	 * 
	 * @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
	 * 
	 * ApiResponse apiResponse; try { AttendanceSummaryDTO summary =
	 * attendanceService.getAttendanceSummary(employeeId, from, to); apiResponse =
	 * ApiResponse.builder().status(Constants.SUCCESS.getDisplayName())
	 * .msg(Constants.SUCCESSFULLY_FETCHED.getDisplayName()).data(summary).build();
	 * return ResponseEntity.status(HttpStatus.OK).body(apiResponse); } catch
	 * (IllegalArgumentException ex) { apiResponse =
	 * ApiResponse.builder().status(Constants.ERROR.getDisplayName())
	 * .msg(Constants.ERROR_FETCHED.getDisplayName()).errorCode("300").data(ex.
	 * getMessage()).build(); return
	 * ResponseEntity.status(HttpStatus.OK).body(apiResponse); } }
	 */
}
