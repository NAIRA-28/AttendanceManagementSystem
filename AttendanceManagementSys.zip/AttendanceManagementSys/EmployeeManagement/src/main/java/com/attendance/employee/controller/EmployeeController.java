package com.attendance.employee.controller;

import com.attendance.employee.config.Constants;
import com.attendance.employee.dto.ApiResponse;
import com.attendance.employee.entities.Employee;
import com.attendance.employee.serviceimpl.EmployeeService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;

    @PostMapping("/create-employee")
    public ResponseEntity<ApiResponse> newEmployeeCreation(@Valid @RequestBody Employee employee) {
        ApiResponse apiResponse;
        try {
            Employee createdEmployee = employeeService.createEmployee(employee);
            apiResponse = ApiResponse.builder().status(Constants.SUCCESS.getDisplayName())
                    .msg(Constants.SUCCESSFULLY_FETCHED.getDisplayName()).data(createdEmployee).build();
            return ResponseEntity.status(HttpStatus.CREATED).body(apiResponse);
        } catch (IllegalArgumentException ex) {
            apiResponse = ApiResponse.builder().status(Constants.ERROR.getDisplayName())
                    .msg(Constants.ERROR_FETCHED.getDisplayName()).errorCode("300").data(ex.getMessage()).build();
            return ResponseEntity.status(HttpStatus.CONFLICT).body(apiResponse);
        }
    }

    @GetMapping("/fetch-all-employee-details")
    public ResponseEntity<ApiResponse> fetchAllEmployeesData() {
        ApiResponse apiResponse;
        try {
        List<Employee> employees = employeeService.getAllEmployees();
        apiResponse = ApiResponse.builder().status(Constants.SUCCESS.getDisplayName())
                    .msg(Constants.SUCCESSFULLY_FETCHED.getDisplayName()).data(employees).build();
        return ResponseEntity.ok(apiResponse);
        } catch (IllegalArgumentException ex) {
            apiResponse = ApiResponse.builder().status(Constants.ERROR.getDisplayName())
                    .msg(Constants.ERROR_FETCHED.getDisplayName()).errorCode("300").data(ex.getMessage()).build();
            return ResponseEntity.status(HttpStatus.OK).body(apiResponse);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> fetchEmployeeById(@PathVariable Long id) {
        ApiResponse apiResponse;
        try{
            Employee employee = employeeService.fetchEmployeeById(id);
            apiResponse = ApiResponse.builder().status(Constants.SUCCESS.getDisplayName())
                    .msg(Constants.SUCCESSFULLY_FETCHED.getDisplayName()).data(employee).build();
            return ResponseEntity.ok(apiResponse);
        }catch (IllegalArgumentException ex){
            apiResponse = ApiResponse.builder().status(Constants.ERROR.getDisplayName())
                    .msg(Constants.ERROR_FETCHED.getDisplayName()).errorCode("300").data(ex.getMessage()).build();
            return ResponseEntity.ok(apiResponse);
        }

    }
}