package com.attendance.employee.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AttendanceRequest {
    @NotNull(message = "Employee ID is required")
    private Long employeeId;
}
//This is your input DTO, used when someone punches attendance.
