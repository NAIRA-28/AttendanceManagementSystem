package com.attendance.employee.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor

@AllArgsConstructor
@Builder
public class AttendanceResponse {
	private Long id;
    private Long employeeId;
    private String employeeName;
    private String type;
    private LocalDateTime timestamp;
    private String message;
}


/*This is the output DTO sent after marking attendance.
{
	  "id": 55,
	  "employeeId": 101,
	  "employeeName": "Naira Sharma",
	  "type": "PUNCH_IN",
	  "timestamp": "2025-11-08T09:00:00",
	  "message": "Naira Sharma punched in successfully"
	}
*/