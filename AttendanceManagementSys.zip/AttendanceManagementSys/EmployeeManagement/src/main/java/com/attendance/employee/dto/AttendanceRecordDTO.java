package com.attendance.employee.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
public class AttendanceRecordDTO {
    private Long id;
    private String type;
    private LocalDateTime timestamp;
}
//this represents a single punch record (either PUNCH_IN or PUNCH_OUT).
//Used inside the DailyAttendanceDTO to store multiple punches in one day.