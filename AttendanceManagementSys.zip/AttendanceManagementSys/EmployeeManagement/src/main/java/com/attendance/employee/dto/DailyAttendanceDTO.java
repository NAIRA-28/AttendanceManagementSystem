package com.attendance.employee.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@Builder
public class DailyAttendanceDTO {
    private LocalDate date;
    private List<AttendanceRecordDTO> records;
    private double totalHours;
    private int totalSessions;
}
//This represents 1 full day of attendance and it'll give something like 
/*{
"date": "2025-11-08",
"records": [
  { "id": 1, "type": "PUNCH_IN", "timestamp": "2025-11-08T09:00:00" },
  { "id": 2, "type": "PUNCH_OUT", "timestamp": "2025-11-08T17:00:00" }
],
"totalHours": 8.0,
"totalSessions": 1
}
*/