package com.attendance.employee.dto;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@RequiredArgsConstructor
public class AttendanceSummaryDTO {
    private Long employeeId;
    private String employeeName;
    private LocalDate fromDate;
    private LocalDate toDate;
    private List<DailyAttendanceDTO> dailyAttendances;
    private double totalWorkingHours;
    private int totalWorkingDays;
    private double averageHoursPerDay;
}




/*   Full report for multiple days
employee info + all daily records + totals
{
"employeeId": 101,
"employeeName": "Naira Sharma",
"fromDate": "2025-11-01",
"toDate": "2025-11-07",
"dailyAttendances": [
  {
    "date": "2025-11-01",
    "records": [
      {"type": "PUNCH_IN", "timestamp": "2025-11-01T09:00"},
      {"type": "PUNCH_OUT", "timestamp": "2025-11-01T17:00"}
    ],
    "totalHours": 8,
    "totalSessions": 1
  },
  ...
],
"totalWorkingHours": 40,
"totalWorkingDays": 5,
"averageHoursPerDay": 8
}
*/