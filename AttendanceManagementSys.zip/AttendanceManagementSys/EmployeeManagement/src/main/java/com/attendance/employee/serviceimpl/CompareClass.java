package com.attendance.employee.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CompareClass {
    public static void main(String[] args) {
        List<Compa2> students = new ArrayList<>();
        students.add(new Compa2(3, "Naira"));
        students.add(new Compa2(1, "Rohuu"));
        students.add(new Compa2(2, "Harshit"));

        Collections.sort(students);  // Uses compareTo()

        System.out.println("Sorted by ID (Natural Order):");
        for (Compa2 s : students) {
            System.out.println(s);
        }
    }
}
